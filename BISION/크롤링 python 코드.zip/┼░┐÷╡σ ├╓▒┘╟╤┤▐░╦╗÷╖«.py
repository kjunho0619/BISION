from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
import cx_Oracle
#from selenium.webdriver import ActionChains
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import os
searchKey = "아이폰"
cpykeyword = [searchKey]

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

url = "https://searchad.naver.com/login?returnUrl=https:%2F%2Fmanage.searchad.naver.com&returnMethod=get"
 


def parser(pageString, totalRelation):
    replaceAll1 = pageString.replace("<!-- -->","")
    replaceAll2 = replaceAll1.replace("<!---->","")
    replaceAll3 = BeautifulSoup(replaceAll2, "html.parser")
    #searchList = bsObj.find("div", {"class":"table-holder"})
    #print(searchList)
    planner = replaceAll3.find_all(class_='common planner')
    pc = replaceAll3.find_all(class_='elenaColumn-monthlyPcQcCnt')
    mobile = replaceAll3.find_all(class_='elenaColumn-monthlyMobileQcCnt')
    
    plan = []
    pcc = []
    mobilee = []
    for i in range(0,1):
        plan.append(planner[i].text)

    for i in range(0,1):
        
        pcc.append(pc[i].text.replace(",",""))
        
    for i in range(0,1):
        mobilee.append(mobile[i].text.replace(",",""))
    
    for i in range(0,1):
        totalRelation.append({"keyword":plan[i],"pccount":pcc[i],"mobilecount":mobilee[i]})
                              
    return totalRelation
    

#url="https://manage.searchad.naver.com/customers/1729161/tool/keyword-planner"

driver.get(url) #enter치는것

totalRelation = []

driver.find_element_by_id("uid").send_keys("didrkfxl")
driver.find_element_by_id("upw").send_keys("jk030303!")
driver.find_element_by_xpath('//*[@id="container"]/div/div/fieldset/div/span/button').click()
sleep(10)
driver.find_element_by_id('week-close-check').click()
sleep(2)
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/a').click()
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/ul/li[3]/a').click()
driver.find_element_by_name("keywordHint").send_keys(cpykeyword)
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[1]/div[3]/button').click()
sleep(1)

pageString=driver.page_source

sleep(1)

totalRelation = parser(pageString, totalRelation);

os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');
def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
 
 
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow
print(totalRelation)
con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

cur.execute('select KEYWORDSEQ from keyword where keyword = :1',cpykeyword)
cur.rowfactory = makeDictFactory(cur)
rows = cur.fetchall()


for i in range(0, len(totalRelation)):
     cpyrlikeyword2 = [(
                   totalRelation[i].get("pccount"),
                   totalRelation[i].get("mobilecount"))]
     cur.executemany("insert into monthcount values(2, :1, :2)",cpyrlikeyword2)

print("성공")

con.commit()
cur.close()
#driver.close()
