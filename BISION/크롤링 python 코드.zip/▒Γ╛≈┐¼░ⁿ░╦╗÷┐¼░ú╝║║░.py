from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
import cx_Oracle
#from selenium.webdriver import ActionChains
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import os

cpykeyword = ["애플"]
#지워주기
searchKey1 = "apple"

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

url = "https://searchad.naver.com/login?returnUrl=https:%2F%2Fmanage.searchad.naver.com&returnMethod=get"


def yeardata(totalYearData):

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    relationkey = bsObj.find("h4",{"class":"modal-title"}).text

    relationkey = relationkey.strip()
    relationkey = relationkey.replace("키워드","")
    relationkey = relationkey.replace(":","")
    relationkey = relationkey.strip()
    relationkeyTotal = []
    for i in range(0,12):
        relationkeyTotal.append(relationkey)
    
    pyautogui.scroll(-500)

    sleep(1)
    pyautogui.moveTo(334,902)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        i5 = i5.replace("\n","")
        i5 = i5.replace("남성desktop:","")
        malePcMonthPer = i5
        
        
    pyautogui.moveTo(392,901)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        i5 = i5.replace("\n","")
        i5 = i5.replace("남성mobile:","")
        maleMobileMonthPer = i5
    
    
    pyautogui.moveTo(525,899)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        i5 = i5.replace("\n","")
        i5 = i5.replace("여성desktop:","")
        femalePcMonthPer = i5
        
    pyautogui.moveTo(577,896)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        i5 = i5.replace("여성mobile:","")
        print(i5)
        femaleMobileMonthPer = i5


    #월별 성별검색량
    genderMonthPer.append({"keyword": relationkey,"malePcMonthPer":malePcMonthPer,"maleMobileMonthPer": maleMobileMonthPer, "femalePcMonthPer" : femalePcMonthPer, "femaleMobileMonthPer" : femaleMobileMonthPer})

    pyautogui.scroll(+500)
    pyautogui.moveTo(1109,245)
    pyautogui.click()
    sleep(1)
    return genderMonthPer

def parser1(pageString1):
    
    yearParser = BeautifulSoup(pageString1, "html.parser")
    year = yearParserdriver.find_element_by_xpath('//*[@id="highcharts-cq6tit7-0"]/div/span/div/div')
    print(year)
    return []



driver.get(url) #enter치는것

driver.find_element_by_id("uid").send_keys("didrkfxl")
driver.find_element_by_id("upw").send_keys("jk030303!")
driver.find_element_by_xpath('//*[@id="container"]/div/div/fieldset/div/span/button').click()
sleep(10)
driver.find_element_by_id('week-close-check').click()
sleep(2)
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/a').click()
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/ul/li[3]/a').click()
driver.find_element_by_name("keywordHint").send_keys(searchKey1)
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[1]/div[3]/button').click()
sleep(3)

driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[2]/div[3]/elena-table/div/div/table/thead/tr[2]/th[2]').click()
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[2]/div[3]/elena-table/div/div/table/thead/tr[2]/th[2]').click()

pageString=driver.page_source
sleep(1)
pyautogui.scroll(-500)
count = 0
y = 430
pyautogui.moveTo(170,y)
pyautogui.click()
sleep(3)

genderMonthPer = []
while count<12 :
    pyautogui.moveTo(170,y)
    pyautogui.click()
    sleep(3)
    yeardata(genderMonthPer)
    count=count+1
    y=y+49
    sleep(1)

print(genderMonthPer)
def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
 
 
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow

os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');
con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

#안되면 맨뒤에 비트윈삭제하기
cur.execute('SELECT a.cpyrlikeywordseq,a.rlikeyword FROM cpyrlikeyword a, cpykeyword b WHERE a.cpykeywordseq = b.cpykeywordseq AND a.cpykeywordseq in (select cpykeywordseq from cpykeyword where cpykeyword=:1)',cpykeyword)
cur.rowfactory = makeDictFactory(cur)
rows = cur.fetchall()

print(rows)
final = []

for i in range(0,len(genderMonthPer)):
    for j in range(0,len(rows)):
        if genderMonthPer[i].get("keyword") == rows[j].get("RLIKEYWORD") :
            final.append({"rlikeyword":genderMonthPer[i].get("keyword"), "cpyrlikeywordseq":rows[j].get("CPYRLIKEYWORDSEQ"),"malepcusercount":genderMonthPer[i].get("malePcMonthPer"),"femalepcusercount":genderMonthPer[i].get("femalePcMonthPer"),"malemobileusercount":genderMonthPer[i].get("maleMobileMonthPer"),"femalemobileusercount":genderMonthPer[i].get("femaleMobileMonthPer")})

print(final)                
for i in range(0, len(final)):
     cpyrlikeyword2 = [(final[i].get("cpyrlikeywordseq"),   
                       final[i].get("malepcusercount"),
                       final[i].get("femalepcusercount"),
                       final[i].get("malemobileusercount"),
                       final[i].get("femalemobileusercount"))]
     cur.executemany("insert into cpyrligendercount values(:1, :2, :3, :4, :5)",cpyrlikeyword2)

print("성공")

con.commit()
cur.close()
#driver.close()
