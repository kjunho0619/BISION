from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
import cx_Oracle
#from selenium.webdriver import ActionChains
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import os
import re
import urllib.request
import urllib.error

searchKey = "애플"
cpykeyword = [searchKey]

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)
url = "https://www.bigkinds.or.kr/"

pt1 = re.compile('[^/\?%*:|"<>.]+')

def downImage(fileurl,filename) :
    dirpath = 'C:/img/kornews/'

    if not os.path.exists(dirpath) :
        os.makedirs(dirpath)
    
    outfile = dirpath + 'kornews-' + filename + '.jpg'
    try :
        urllib.request.urlretrieve( fileurl , outfile )
    except URLError as e :
        print(e)
        print('error url = ' + fileurl)
        print('error filename = ' + outfile)
    sleep(1)

def filenameCheck( filename ) :
    txt = ''
    arr = pt1.findall(filename)
    if len(arr) > 0 :
        for t in arr :
            txt += t
        return txt
    else :
        return filename

def yeardata(newsTotal):
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    title = driver.find_element_by_xpath('/html/body/div[11]/div/div/div[1]/h4').text
    
    date = driver.find_element_by_xpath('//*[@id="news-detail-modal"]/div/div/div[1]/div[2]/span[4]').text

    content = driver.find_element_by_xpath('//*[@id="news-detail-modal"]/div/div/div[2]/div').text

    if bsObj.find("div",{"class":"text-center news-detail__image mt-2 mb-2"}) is not None :
        imgDivTag = bsObj.find("div",{"class":"text-center news-detail__image mt-2 mb-2"})
        imgSrc = imgDivTag.find("img").get("src")
        filename = title
        filename = filenameCheck(filename)
        fileurl=imgSrc
        downImage(fileurl,filename)
        imgSrc = 'C:/img/kornews/kornews-'+title + '.jpg'
        
        
    else :
        imgSrc = ""
    
    fileurl=imgSrc

    content = content.replace("\n","",100)
    if driver.find_element_by_xpath('//*[@id="news-detail-modal"]/div/div/div[1]/div[2]/span[5]').text is not None :
        maker = driver.find_element_by_xpath('//*[@id="news-detail-modal"]/div/div/div[1]/div[2]/span[5]').text
        print(maker)
    newsTotal.append({"keyword":searchKey,"news_division":"KOR", "news_title":title, "news_content":content,"news_image":fileurl, "news_date":date,"byline":maker, "filename":title,"fileurl":imgSrc})
    return newsTotal
    
driver.get(url) #enter치는것

driver.find_element_by_xpath('//*[@id="total-search-key"]').send_keys(cpykeyword)
driver.find_element_by_xpath('//*[@id="news-search-form"]/div/div/div/div[1]/span/button').click()
sleep(1)
driver.find_element_by_xpath('//*[@id="filter-category-001000000"]').click()
driver.find_element_by_xpath('//*[@id="filter-category-002000000"]').click()
driver.find_element_by_xpath('//*[@id="filter-category-004000000"]').click()
driver.find_element_by_xpath('//*[@id="filter-category-005000000"]').click()
driver.find_element_by_xpath('//*[@id="filter-category-008000000"]').click()

newsTotal = []
count = 1
cc = 4
while cc<6 :
    
    while count<11 :
        sleep(3)
        driver.find_element_by_xpath("//*[@id='news-results']/div["+str(count)+"]/div[2]/h4").click()
        yeardata(newsTotal)
        sleep(3)
        driver.find_element_by_xpath("//*[@id='news-detail-modal']/div/div/div[1]/button/span").click()
        count = count+1
    sleep(1) 
    driver.find_element_by_xpath("//*[@id='news-results-pagination']/ul/li["+str(cc)+"]/a").click()
    cc = cc+1
    count = 6
def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
 
 
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow

os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');
con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

cur.execute('select cpykeywordseq,cpykeyword from cpykeyword where cpykeyword = :1',cpykeyword)
cur.rowfactory = makeDictFactory(cur)
rows = cur.fetchall()

final = []
for row in rows :
   print(row)
   cpykeywordseq = row['CPYKEYWORDSEQ']
   print(cpykeywordseq)

for row in rows :
   print(row)
   cpykeyword1 = row['CPYKEYWORD']
   print(cpykeyword1)
   
for i in range(0,len(newsTotal)):
    if newsTotal[i].get("keyword") == cpykeyword1 :
        final.append({"cpykeywordseq":cpykeywordseq, "news_division":newsTotal[i].get("news_division"),"news_title":newsTotal[i].get("news_title"),"news_content":newsTotal[i].get("news_content"),"news_image":newsTotal[i].get("news_image"),"news_date":newsTotal[i].get("news_date"),"byline":newsTotal[i].get("byline")})
#print(final)
for i in range(0, len(final)):
     testInsert= [(cpykeywordseq,
                   final[i].get("news_division"),
                   final[i].get("news_title"),
                   final[i].get("news_content"),
                   final[i].get("news_image"),
                   final[i].get("news_date"),
                   final[i].get("byline"))]
     cur.executemany("insert into cpynewsinfo(news_no, cpykeywordseq, news_division, news_title, news_content, news_image, news_date, byline) values(news_no.nextval, :1, :2, :3, :4, :5, :6, :7)",testInsert)

print("성공")

con.commit()
cur.close()
#driver.close()
