from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
import cx_Oracle
#from selenium.webdriver import ActionChains
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import os
searchKey = "갤럭시노트"
cpykeyword = [searchKey]

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

url = "https://searchad.naver.com/login?returnUrl=https:%2F%2Fmanage.searchad.naver.com&returnMethod=get"
    
def yeardata(allOld):

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    relationkey = bsObj.find("h4",{"class":"modal-title"}).text

    relationkey = relationkey.strip()
    relationkey = relationkey.replace("키워드","")
    relationkey = relationkey.replace(":","")
    relationkey = relationkey.strip()
 
    
    pyautogui.scroll(-600)
    
    pcOldTotal = []
    mobileOldTotal = []
    pcOld = []
    mobileOld = []
    pcCount = 1
    mobileCount = 1
    deskX = 805
    mobileX = 822
    
    while pcCount<6 :
    
        pyautogui.moveTo(deskX,771)
        pyautogui.moveTo(deskX,772)
        pageString1=driver.page_source
        bsObj= BeautifulSoup(pageString1, "html.parser")
        searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
        for i in searchList:
                i2 = i.text
                i3 = i2.strip()
                i4 = i3.strip("\n")
                i5 = i4.replace("\n","")
                i5 = i5.replace(" ","")
                i5 = i5.replace(",","")
                pcOld.append(i5[0:5])
                pcOldValue = i5[13:]
                deskX=deskX+55
                pcCount=pcCount+1
                pcOldTotal.append(pcOldValue)
            
                
    pyautogui.moveTo(1080,771)
    pyautogui.moveTo(1080,772)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
    for i in searchList:
         i2 = i.text
         i3 = i2.strip()
         i4 = i3.strip("\n")
         i5 = i4.replace("\n","")
         i5 = i5.replace(" ","")
         i5 = i5.replace(",","")
         pcOld.append(i5[0:3])
         pcOldTotal.append(i5[11:])
        
    while mobileCount<6 :
        pyautogui.moveTo(mobileX,771)
        pyautogui.moveTo(mobileX,772)
        pageString1=driver.page_source
        bsObj= BeautifulSoup(pageString1, "html.parser")
        searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
        for i in searchList:
                i2 = i.text
                i3 = i2.strip()
                i4 = i3.strip("\n")
                i5 = i4.replace("\n","")
                i5 = i5.replace(" ","")
                i5 = i5.replace(",","")
                mobileOldTotal.append(i5[12:])
                mobileOld.append(i5[0:5])
                mobileX=mobileX+55
                mobileCount=mobileCount+1

    pyautogui.moveTo(1095,771)
    pyautogui.moveTo(1095,772)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobileOld.append(i5[0:3])
        mobileOldTotal.append(i5[10:])

    pcTotoalCount = 0
    mobileTotalCount = 0

    for i in range(0,len(pcOldTotal)):
        pcTotoalCount = pcTotoalCount + float(pcOldTotal[i])

    for i in range(0, len(mobileOldTotal)):
        mobileTotalCount = mobileTotalCount + float(mobileOldTotal[i])

    pcTotoalCount = 100-pcTotoalCount
    pcTotoalCount = round(pcTotoalCount,2)
    mobileTotalCount = 100-mobileTotalCount
    mobileTotalCount = round(mobileTotalCount,2)
    youngOld ="0~12"
    allOld.append({"keyword":relationkey,"age":youngOld,"pcmonthcount":pcTotoalCount,"mobilemonthcount":mobileTotalCount})
    
    for i in range(0,6):
        allOld.append({"keyword":relationkey,"age":pcOld[i],"pcmonthcount": pcOldTotal[i], "mobilemonthcount":mobileOldTotal[i]})
    pyautogui.scroll(+600)
    pyautogui.moveTo(1109,245)
    pyautogui.click()
    return allOld

def parser1(pageString1):
    
    yearParser = BeautifulSoup(pageString1, "html.parser")
    year = yearParserdriver.find_element_by_xpath('//*[@id="highcharts-cq6tit7-0"]/div/span/div/div')
    print(year)
    return []

driver.get(url) #enter치는것

driver.find_element_by_id("uid").send_keys("didrkfxl")
driver.find_element_by_id("upw").send_keys("jk030303!")
driver.find_element_by_xpath('//*[@id="container"]/div/div/fieldset/div/span/button').click()
sleep(10)
driver.find_element_by_id('week-close-check').click()
sleep(2)
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/a').click()
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/ul/li[3]/a').click()
driver.find_element_by_name("keywordHint").send_keys(cpykeyword)
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[1]/div[3]/button').click()
sleep(3)

pageString=driver.page_source
sleep(1)

sleep(3)
pyautogui.scroll(-200)
pyautogui.moveTo(174,747)
pyautogui.click()
allOld = []

sleep(3)
yeardata(allOld)


print(allOld)

def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
 
 
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow

os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');
def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
 
 
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow

con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

cur.execute("SELECT a.cpyrlikeywordseq,a.rlikeyword FROM cpyrlikeyword a, cpykeyword b WHERE a.cpykeywordseq = b.cpykeywordseq AND a.cpykeywordseq in (select cpykeywordseq from cpykeyword where cpykeyword = '삼성') and rlikeyword=:1",cpykeyword)
cur.rowfactory = makeDictFactory(cur)
rows = cur.fetchall()

print(rows)

print(rows)
final = []

for i in range(0,len(allOld)):
    for j in range(0,len(rows)):
        if allOld[i].get("keyword") == rows[j].get("RLIKEYWORD") :
            final.append({"rlikeyword":allOld[i].get("keyword"), "cpyrlikeywordseq":rows[j].get("CPYRLIKEYWORDSEQ"),"age":allOld[i].get("age"),"pcmonthcount":allOld[i].get("pcmonthcount"),"mobilemonthcount":allOld[i].get("mobilemonthcount")})

print(final)                
for i in range(0, len(final)):
     cpyrlikeyword2 = [(final[i].get("cpyrlikeywordseq"),
                       final[i].get("age"),
                       final[i].get("pcmonthcount"),
                       final[i].get("mobilemonthcount"))]
     cur.executemany("insert into cpyrliagecount values(:1, :2, :3, :4)",cpyrlikeyword2)

print("성공")

con.commit()
cur.close()
#driver.close()
