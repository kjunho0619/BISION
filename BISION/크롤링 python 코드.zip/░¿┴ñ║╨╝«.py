from bs4 import BeautifulSoup
from selenium import webdriver
from time import sleep
import cx_Oracle
import os

os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

con = cx_Oracle.connect("bision/project@localhost:1521/XE")
#여기만 수정해주면됨 ex)"소프트뱅크","JPN" / "애플",ENG / 여기는 일본어,영어만
#성공 뜨면 끝
keyword = ["애플", "ENG"]

cur = con.cursor()
cur.execute("select * from cpynewsinfo where cpykeywordseq in (select cpykeywordseq from cpykeyword where cpykeyword= :1) and news_division = :2",keyword)
rows = cur.fetchall()

newsContent = []
newsNoList = []
for row in rows:
    newsNoList.append(row[0])
    newsContent.append(row[4].read())
#print(newsContent)

url = "https://azure.microsoft.com/ko-kr/services/cognitive-services/text-analytics/"
driver.get(url) #주소 입력하고 enter

sleep(5)

emtanalysisList = []

for i in newsContent:
    driver.find_element_by_id("text-analytics-demo").clear();
    driver.find_element_by_id("text-analytics-demo").send_keys(i[:4500])

    driver.find_element_by_xpath('//*[@id="main"]/section[1]/div[3]/div[1]/form/div[2]/input').click()
    sleep(3)

    pageString = driver.page_source
    bsObj = BeautifulSoup(pageString, "html.parser")
    emtanalysisHtml = bsObj.find("div",{"class","absolutely-centered"})
    emtanalysisText1 = emtanalysisHtml.text
    emtanalysisText2 = emtanalysisText1.strip()
    emtanalysis = emtanalysisText2.strip("%")
    print(emtanalysis)
    emtanalysisList.append(emtanalysis)

print(emtanalysisList)

for i in range(0,len(newsNoList)):
    emtanalysisValue = [(emtanalysisList[i],
                         newsNoList[i])]
    cur.executemany("update cpynewsinfo set emtanalysis = (:1-50) where news_no = :2",emtanalysisValue)
    
print("성공")
con.commit()
cur.close()



    
