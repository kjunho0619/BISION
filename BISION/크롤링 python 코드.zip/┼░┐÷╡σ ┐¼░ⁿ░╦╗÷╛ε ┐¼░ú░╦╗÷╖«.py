from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
import cx_Oracle
#from selenium.webdriver import ActionChains
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import os

searchKey = "아이폰"
cpykeyword = [searchKey]
#지워주기
searchKey1 = searchKey

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

url = "https://searchad.naver.com/login?returnUrl=https:%2F%2Fmanage.searchad.naver.com&returnMethod=get"


def yeardata(totalYearData):
 
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    relationkey = bsObj.find("h4",{"class":"modal-title"}).text
    
    relationkey = relationkey.strip()
    relationkey = relationkey.replace("키워드","")
    relationkey = relationkey.replace(":","")
    relationkey = relationkey.strip()
    relationkeyTotal = []
    for i in range(0,12):
        relationkeyTotal.append(relationkey)
    print(relationkey)
    print(relationkeyTotal)
    pyautogui.moveTo(1062,419)
    pyautogui.click()
    sleep(2)
    pyautogui.moveTo(323,451)
    pyautogui.moveTo(324,451)
    pyautogui.moveTo(325,451)
    pyautogui.moveTo(325,452)

    pcdate = []
    pc=[]
    
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
    pcdate.append(i5[0:7])
    pc.append(i5[15:])

   
    pyautogui.moveTo(393,451)
    pyautogui.moveTo(394,451)
    pyautogui.moveTo(395,451)
    pyautogui.moveTo(395,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])

    pyautogui.moveTo(463,451)
    pyautogui.moveTo(464,451)
    pyautogui.moveTo(465,451)
    pyautogui.moveTo(465,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(533,451)
    pyautogui.moveTo(534,451)
    pyautogui.moveTo(535,451)
    pyautogui.moveTo(535,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(603,451)
    pyautogui.moveTo(604,451)
    pyautogui.moveTo(605,451)
    pyautogui.moveTo(605,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])

    
    pyautogui.moveTo(673,451)
    pyautogui.moveTo(674,451)
    pyautogui.moveTo(675,451)
    pyautogui.moveTo(675,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(733,451)
    pyautogui.moveTo(734,451)
    pyautogui.moveTo(735,451)
    pyautogui.moveTo(735,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(803,451)
    pyautogui.moveTo(804,451)
    pyautogui.moveTo(805,451)
    pyautogui.moveTo(805,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])
 

    pyautogui.moveTo(873,451)
    pyautogui.moveTo(874,451)
    pyautogui.moveTo(875,451)
    pyautogui.moveTo(875,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])
 

    pyautogui.moveTo(943,451)
    pyautogui.moveTo(944,451)
    pyautogui.moveTo(945,451)
    pyautogui.moveTo(945,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(1013,451)
    pyautogui.moveTo(1014,451)
    pyautogui.moveTo(1015,451)
    pyautogui.moveTo(1015,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])

    pyautogui.moveTo(1083,451)
    pyautogui.moveTo(1084,451)
    pyautogui.moveTo(1085,451)
    pyautogui.moveTo(1085,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(1062,419)
    pyautogui.click()
    pyautogui.moveTo(920,419)
    pyautogui.click()

    sleep(2)
    pyautogui.moveTo(323,451)
    pyautogui.moveTo(324,451)
    pyautogui.moveTo(325,451)
    pyautogui.moveTo(325,452)

    mobile = []

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])

       
    pyautogui.moveTo(393,451)
    pyautogui.moveTo(394,451)
    pyautogui.moveTo(395,451)
    pyautogui.moveTo(395,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])

    
    pyautogui.moveTo(463,451)
    pyautogui.moveTo(464,451)
    pyautogui.moveTo(465,451)
    pyautogui.moveTo(465,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(533,451)
    pyautogui.moveTo(534,451)
    pyautogui.moveTo(535,451)
    pyautogui.moveTo(535,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(603,451)
    pyautogui.moveTo(604,451)
    pyautogui.moveTo(605,451)
    pyautogui.moveTo(605,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(673,451)
    pyautogui.moveTo(674,451)
    pyautogui.moveTo(675,451)
    pyautogui.moveTo(675,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(733,451)
    pyautogui.moveTo(734,451)
    pyautogui.moveTo(735,451)
    pyautogui.moveTo(735,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(803,451)
    pyautogui.moveTo(804,451)
    pyautogui.moveTo(805,451)
    pyautogui.moveTo(805,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(873,451)
    pyautogui.moveTo(874,451)
    pyautogui.moveTo(875,451)
    pyautogui.moveTo(875,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(943,451)
    pyautogui.moveTo(944,451)
    pyautogui.moveTo(945,451)
    pyautogui.moveTo(945,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(1013,451)
    pyautogui.moveTo(1014,451)
    pyautogui.moveTo(1015,451)
    pyautogui.moveTo(1015,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(1083,451)
    pyautogui.moveTo(1084,451)
    pyautogui.moveTo(1085,451)
    pyautogui.moveTo(1085,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
                                                
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])

    for i in range(0,12):
        totalYearData.append({"keyword": relationkeyTotal[i],"day": pcdate[i] + "-01","PcSearch" : pc[i], "MoblieSearch" : mobile[i]})

    pyautogui.scroll(+500)
    pyautogui.moveTo(1109,245)
    pyautogui.click()
    sleep(1)
    return totalYearData

def parser1(pageString1):
    
    yearParser = BeautifulSoup(pageString1, "html.parser")
    year = yearParserdriver.find_element_by_xpath('//*[@id="highcharts-cq6tit7-0"]/div/span/div/div')
    print(year)
    return []



driver.get(url) #enter치는것

driver.find_element_by_id("uid").send_keys("didrkfxl")
driver.find_element_by_id("upw").send_keys("jk030303!")
driver.find_element_by_xpath('//*[@id="container"]/div/div/fieldset/div/span/button').click()
sleep(10)
driver.find_element_by_id('week-close-check').click()
sleep(2)
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/a').click()
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/ul/li[3]/a').click()
driver.find_element_by_name("keywordHint").send_keys(searchKey)
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[1]/div[3]/button').click()
sleep(3)

driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[2]/div[3]/elena-table/div/div/table/thead/tr[2]/th[2]').click()
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[2]/div[3]/elena-table/div/div/table/thead/tr[2]/th[2]').click()

pageString=driver.page_source
sleep(3)
pyautogui.scroll(-500)
count = 0
y = 430
pyautogui.moveTo(170,y)
pyautogui.click()
sleep(3)

totalYearData = []
while count<3 :
    pyautogui.moveTo(170,y)
    pyautogui.click()
    sleep(3)
    yeardata(totalYearData)
    count=count+1
    y=y+49
    sleep(1)

print(totalYearData)
os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');
def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
 
 
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow

con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

cur.execute('SELECT a.rlikeywordseq,a.keyword FROM rlikeyword a, keyword b WHERE a.keywordseq = b.keywordseq AND a.keywordseq in (select keywordseq from keyword where keyword=:1)',cpykeyword)
cur.rowfactory = makeDictFactory(cur)
rows = cur.fetchall()

print(rows)
final = []

for i in range(0,len(totalYearData)):
    for j in range(0,len(rows)):
        if totalYearData[i].get("keyword") == rows[j].get("KEYWORD") :
            final.append({"rlikeyword":totalYearData[i].get("keyword"), "rlikeywordseq":rows[j].get("RLIKEYWORDSEQ"),"month":totalYearData[i].get("day"),"pcmonthcount":totalYearData[i].get("PcSearch"),"mobilemonthcount":totalYearData[i].get("MoblieSearch")})

print(final)                
for i in range(0, len(totalYearData)):
     cpyrlikeyword2 = [(final[i].get("rlikeywordseq"),   
                       final[i].get("month"),
                       final[i].get("pcmonthcount"),
                       final[i].get("mobilemonthcount"))]
     cur.executemany("insert into rliyearcount values(:1, :2, :3, :4)",cpyrlikeyword2)

print("성공")

con.commit()
cur.close()
#driver.close()
