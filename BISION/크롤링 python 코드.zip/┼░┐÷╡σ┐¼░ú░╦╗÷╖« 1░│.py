from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
import cx_Oracle
#from selenium.webdriver import ActionChains
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import os
import urllib.request
import urllib.error

searchKey = "아이폰"
keyword = [searchKey]
#sql seq수정하

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

url = "https://searchad.naver.com/login?returnUrl=https:%2F%2Fmanage.searchad.naver.com&returnMethod=get"


    
def yeardata(totalYearData):
    sleep(2)
    pyautogui.scroll(-500)
    pyautogui.moveTo(170,430)
    pyautogui.click()
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    relationkey = bsObj.find("h4",{"class":"modal-title"}).text

    relationkey = relationkey.strip()
    relationkey = relationkey.replace("키워드","")
    relationkey = relationkey.replace(":","")
    relationkey = relationkey.strip()
    print(relationkey)
    pyautogui.moveTo(1062,419)
    pyautogui.click()
    sleep(2)
    pyautogui.moveTo(323,451)
    pyautogui.moveTo(324,451)
    pyautogui.moveTo(325,451)
    pyautogui.moveTo(325,452)

    pcdate = []
    pc=[]
    
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
    pcdate.append(i5[0:7])
    pc.append(i5[15:])

   
    pyautogui.moveTo(393,451)
    pyautogui.moveTo(394,451)
    pyautogui.moveTo(395,451)
    pyautogui.moveTo(395,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])

    pyautogui.moveTo(463,451)
    pyautogui.moveTo(464,451)
    pyautogui.moveTo(465,451)
    pyautogui.moveTo(465,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(533,451)
    pyautogui.moveTo(534,451)
    pyautogui.moveTo(535,451)
    pyautogui.moveTo(535,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(603,451)
    pyautogui.moveTo(604,451)
    pyautogui.moveTo(605,451)
    pyautogui.moveTo(605,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])

    
    pyautogui.moveTo(673,451)
    pyautogui.moveTo(674,451)
    pyautogui.moveTo(675,451)
    pyautogui.moveTo(675,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(733,451)
    pyautogui.moveTo(734,451)
    pyautogui.moveTo(735,451)
    pyautogui.moveTo(735,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(803,451)
    pyautogui.moveTo(804,451)
    pyautogui.moveTo(805,451)
    pyautogui.moveTo(805,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])
 

    pyautogui.moveTo(873,451)
    pyautogui.moveTo(874,451)
    pyautogui.moveTo(875,451)
    pyautogui.moveTo(875,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])
 

    pyautogui.moveTo(943,451)
    pyautogui.moveTo(944,451)
    pyautogui.moveTo(945,451)
    pyautogui.moveTo(945,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(1013,451)
    pyautogui.moveTo(1014,451)
    pyautogui.moveTo(1015,451)
    pyautogui.moveTo(1015,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])

    pyautogui.moveTo(1083,451)
    pyautogui.moveTo(1084,451)
    pyautogui.moveTo(1085,451)
    pyautogui.moveTo(1085,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        pcdate.append(i5[0:7])
        pc.append(i5[15:])


    pyautogui.moveTo(1062,419)
    pyautogui.click()
    pyautogui.moveTo(920,419)
    pyautogui.click()

    sleep(2)
    pyautogui.moveTo(323,451)
    pyautogui.moveTo(324,451)
    pyautogui.moveTo(325,451)
    pyautogui.moveTo(325,452)

    mobile = []

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])

       
    pyautogui.moveTo(393,451)
    pyautogui.moveTo(394,451)
    pyautogui.moveTo(395,451)
    pyautogui.moveTo(395,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])

    
    pyautogui.moveTo(463,451)
    pyautogui.moveTo(464,451)
    pyautogui.moveTo(465,451)
    pyautogui.moveTo(465,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(533,451)
    pyautogui.moveTo(534,451)
    pyautogui.moveTo(535,451)
    pyautogui.moveTo(535,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(603,451)
    pyautogui.moveTo(604,451)
    pyautogui.moveTo(605,451)
    pyautogui.moveTo(605,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(673,451)
    pyautogui.moveTo(674,451)
    pyautogui.moveTo(675,451)
    pyautogui.moveTo(675,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(733,451)
    pyautogui.moveTo(734,451)
    pyautogui.moveTo(735,451)
    pyautogui.moveTo(735,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(803,451)
    pyautogui.moveTo(804,451)
    pyautogui.moveTo(805,451)
    pyautogui.moveTo(805,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(873,451)
    pyautogui.moveTo(874,451)
    pyautogui.moveTo(875,451)
    pyautogui.moveTo(875,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(943,451)
    pyautogui.moveTo(944,451)
    pyautogui.moveTo(945,451)
    pyautogui.moveTo(945,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(1013,451)
    pyautogui.moveTo(1014,451)
    pyautogui.moveTo(1015,451)
    pyautogui.moveTo(1015,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])


    pyautogui.moveTo(1083,451)
    pyautogui.moveTo(1084,451)
    pyautogui.moveTo(1085,451)
    pyautogui.moveTo(1085,452)

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
                                                
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        mobile.append(i5[14:])



    for i in range(0,12):
        totalYearData.append({"keyword": relationkey,"day": pcdate[i] + "-01","PcSearch" : pc[i], "MoblieSearch" : mobile[i]})

    return totalYearData
    
def parser(pageString):
    replaceAll1 = pageString.replace("<!-- -->","")
    replaceAll2 = replaceAll1.replace("<!---->","")
    replaceAll3 = BeautifulSoup(replaceAll2, "html.parser")
    #searchList = bsObj.find("div", {"class":"table-holder"})
    #print(searchList)
    planner = replaceAll3.find_all(class_='common planner')
    pc = replaceAll3.find_all(class_='elenaColumn-monthlyPcQcCnt')
    mobile = replaceAll3.find_all(class_='elenaColumn-monthlyMobileQcCnt')
    
    for i in range(0,11):
        print(planner[i].text)

    for i in range(0,11):
        print(pc[i].text)
        
    for i in range(0,11):
        print(mobile[i].text)

    
    return []
    
def crawl(url):
    data=requests.get(url)
    print(data,url)
    return data.content
    

def parser1(pageString1):
    
    yearParser = BeautifulSoup(pageString1, "html.parser")
    year = yearParserdriver.find_element_by_xpath('//*[@id="highcharts-cq6tit7-0"]/div/span/div/div')
    print(year)
    return []

#url="https://manage.searchad.naver.com/customers/1729161/tool/keyword-planner"

driver.get(url) #enter치는것
print(pyautogui.position())
print(pyautogui.size())

driver.find_element_by_id("uid").send_keys("didrkfxl")
driver.find_element_by_id("upw").send_keys("jk030303!")
driver.find_element_by_xpath('//*[@id="container"]/div/div/fieldset/div/span/button').click()
sleep(10)
driver.find_element_by_id('week-close-check').click()
sleep(2)
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/a').click()
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/ul/li[3]/a').click()
driver.find_element_by_name("keywordHint").send_keys(keyword)
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[1]/div[3]/button').click()
sleep(3)
totalYearData = []
yeardata(totalYearData)
sleep(1)
print(totalYearData)
def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow

os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');

def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow

con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

cur.execute('select keywordseq from keyword where keyword = :1',keyword)
cur.rowfactory = makeDictFactory(cur)
rows = cur.fetchall()

print(rows)

for row in rows :
   print(row)
   keywordseq = row['KEYWORDSEQ']




for i in range(0, len(totalYearData)):
     cpyrlikeyword2 = [(2,
                   totalYearData[i].get("day"),
                   totalYearData[i].get("PcSearch"),
                   totalYearData[i].get("MoblieSearch"))]
     print("성공")
     cur.executemany("insert into yearcount values(:1, :2, :3, :4)",cpyrlikeyword2)
     print("성공")

con.commit()
cur.close()
#driver.close()
