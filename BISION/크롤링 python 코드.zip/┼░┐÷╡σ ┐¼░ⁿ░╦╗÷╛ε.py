from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
import cx_Oracle
#from selenium.webdriver import ActionChains
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import os

searchKey = "아이폰"
cpykeyword = [searchKey]

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

url = "https://searchad.naver.com/login?returnUrl=https:%2F%2Fmanage.searchad.naver.com&returnMethod=get"
 


def parser(pageString, totalRelation):
    replaceAll1 = pageString.replace("<!-- -->","")
    replaceAll2 = replaceAll1.replace("<!---->","")
    replaceAll3 = BeautifulSoup(replaceAll2, "html.parser")
    #searchList = bsObj.find("div", {"class":"table-holder"})
    #print(searchList)
    planner = replaceAll3.find_all(class_='common planner')
    pc = replaceAll3.find_all(class_='elenaColumn-monthlyPcQcCnt')
    mobile = replaceAll3.find_all(class_='elenaColumn-monthlyMobileQcCnt')

    plan = []
    pcc = []
    mobilee = []
    for i in range(0,3):
        plan.append(planner[i].text)

    for i in range(0,3):
        pcc.append(pc[i].text)
        
    for i in range(0,3):
        mobilee.append(mobile[i].text)

    for i in range(0,3):
        totalRelation.append({"rlikeyword":plan[i],"pccount":pcc[i],"mobilecount":mobilee[i]})
                              
    return totalRelation
    

#url="https://manage.searchad.naver.com/customers/1729161/tool/keyword-planner"

driver.get(url) #enter치는것

totalRelation = []

driver.find_element_by_id("uid").send_keys("didrkfxl")
driver.find_element_by_id("upw").send_keys("jk030303!")
driver.find_element_by_xpath('//*[@id="container"]/div/div/fieldset/div/span/button').click()
sleep(10)
driver.find_element_by_id('week-close-check').click()
sleep(2)
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/a').click()
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/ul/li[3]/a').click()
driver.find_element_by_name("keywordHint").send_keys(searchKey)
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[1]/div[3]/button').click()
sleep(1)

driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[2]/div[3]/elena-table/div/div/table/thead/tr[2]/th[2]').click()
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[2]/div[3]/elena-table/div/div/table/thead/tr[2]/th[2]').click()

pageString=driver.page_source

sleep(1)

totalRelation = parser(pageString, totalRelation);

print(totalRelation)
#연간 pc값 뽑기

os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');
con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

seq = 1
#seq수동으로입력하
for i in range(0, len(totalRelation)):
     cpyrlikeywordd = [(seq,
         totalRelation[i].get("rlikeyword"))]
     cur.executemany("insert into rlikeyword values(rlikeywordseq.nextval,:1,:2)",cpyrlikeywordd)
     print("성공")
print("성공")
con.commit()
cur.close()
#driver.close()
