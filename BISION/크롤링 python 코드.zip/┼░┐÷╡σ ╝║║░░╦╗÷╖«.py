from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
import cx_Oracle
#from selenium.webdriver import ActionChains
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import os

keyword = ["아이폰"]
driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

url = "https://searchad.naver.com/login?returnUrl=https:%2F%2Fmanage.searchad.naver.com&returnMethod=get"
    
def yeardata(genderMonthPer):

    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    relationkey = bsObj.find("h4",{"class":"modal-title"}).text

    relationkey = relationkey.strip()
    relationkey = relationkey.replace("키워드","")
    relationkey = relationkey.replace(":","")
    relationkey = relationkey.strip()
    print(relationkey)
    
    pyautogui.scroll(-500)
    
    pyautogui.moveTo(334,902)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"})
    
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        i5 = i5.replace("\n","")
        i5 = i5[-5:]
        i5 = i5.replace(":","")
        malePcMonthPer = i5
        
        
    pyautogui.moveTo(392,901)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        i5 = i5.replace("\n","")
        i5 = i5[-5:]
        i5 = i5.replace(":","")
        maleMobileMonthPer = i5
    
    
    pyautogui.moveTo(525,899)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        i5 = i5.replace("\n","")
        i5 = i5[-5:]
        i5 = i5.replace(":","")
        femalePcMonthPer = i5
        
    pyautogui.moveTo(577,896)
    pageString1=driver.page_source
    bsObj= BeautifulSoup(pageString1, "html.parser")
    searchList = bsObj.findAll("div", {"class":"highcharts-label highcharts-tooltip highcharts-color-undefined"}) 
    for i in searchList:
        i2 = i.text
        i3 = i2.strip()
        i4 = i3.strip("\n")
        i5 = i4.replace("\n","")
        i5 = i5.replace(" ","")
        i5 = i5.replace(",","")
        i5 = i5[-5:]
        i5 = i5.replace(":","")
        femaleMobileMonthPer = i5
        


    #월별 성별검색량
    genderMonthPer.append({"keyword": relationkey,"malePcMonthPer":malePcMonthPer,"maleMobileMonthPer": maleMobileMonthPer, "femalePcMonthPer" : femalePcMonthPer, "femaleMobileMonthPer" : femaleMobileMonthPer})
    
    return genderMonthPer
    

def parser1(pageString1):
    
    yearParser = BeautifulSoup(pageString1, "html.parser")
    year = yearParserdriver.find_element_by_xpath('//*[@id="highcharts-cq6tit7-0"]/div/span/div/div')
    print(year)
    return []

#url="https://manage.searchad.naver.com/customers/1729161/tool/keyword-planner"

driver.get(url) #enter치는것
print(pyautogui.position())
print(pyautogui.size())

driver.find_element_by_id("uid").send_keys("didrkfxl")
driver.find_element_by_id("upw").send_keys("jk030303!")
driver.find_element_by_xpath('//*[@id="container"]/div/div/fieldset/div/span/button').click()
sleep(10)
driver.find_element_by_id('week-close-check').click()
sleep(2)
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/a').click()
driver.find_element_by_xpath('//*[@id="navbar-common-header-collapse"]/ul/li[3]/ul/li[3]/a').click()
driver.find_element_by_name("keywordHint").send_keys(keyword)
driver.find_element_by_xpath('/html/body/elena-root/elena-wrap/div/div[2]/elena-tool-wrap/div/div/div/div/elena-keyword-planner/div[2]/div[1]/div[1]/div[3]/button').click()
sleep(3)

pageString=driver.page_source

sleep(3)

pyautogui.scroll(-500)

count = 0
y = 430
pyautogui.moveTo(170,y)
pyautogui.click()
sleep(3)

genderMonthPer = []
yeardata(genderMonthPer)
print(genderMonthPer)
os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');
def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
 
 
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow
os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');
con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

cur.execute('select keywordseq from keyword where keyword = :1',keyword)
cur.rowfactory = makeDictFactory(cur)
rows = cur.fetchall()

print(rows)

for row in rows :
   print(row)
   keywordseq = row['KEYWORDSEQ']
   print(keywordseq)
print(keywordseq)
for i in range(0, len(genderMonthPer)):
     cpyrlikeyword1 = [(keywordseq,
                        genderMonthPer[i].get("malePcMonthPer"),
                        genderMonthPer[i].get("femalePcMonthPer"),
                        genderMonthPer[i].get("maleMobileMonthPer"),
                        genderMonthPer[i].get("femaleMobileMonthPer"))]
     cur.executemany("insert into gendercount values(:1, :2, :3, :4, :5)",cpyrlikeyword1)
     print("성공")
print("성공")
con.commit()
cur.close()

#driver.close()
