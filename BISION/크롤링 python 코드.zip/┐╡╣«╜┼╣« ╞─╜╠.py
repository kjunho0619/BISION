from bs4 import BeautifulSoup
from selenium import webdriver
from time import sleep
import os
import cx_Oracle
import pyautogui
import datetime
import urllib.request
import urllib.error
import re

searchKey = "애플"
cpykeyword = [searchKey]

# 윈도우에 사용 불가능한 특수문자
pt1 = re.compile('[^/\?%*:|"<>.]+')

os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

def downImage( fileurl, filename ) :
    dirpath = 'C:/img/engnews/'

    if not os.path.exists(dirpath) :
        os.makedirs(dirpath)
    
    outfile = dirpath + 'engnews-' + filename + '.jpg'
    try :
        urllib.request.urlretrieve( fileurl , outfile )
    except URLError as e :
        print(e)
        print('error url = ' + fileurl)
        print('error filename = ' + outfile)
    sleep(1)
    return outfile

def filenameCheck( filename ) :
    txt = ''
    arr = pt1.findall(filename)
    if len(arr) > 0 :
        for t in arr :
            txt += t
        return txt
    else :
        return filename

def dateParser(newsList):
    dateTagtList = []
    dateTextList = []
    now = datetime.datetime.now()
    nowDate = now.strftime('%Y-%m-%d')
    
    datesList = newsList.findAll("p",{"class","fontDate2"})
    for i in datesList:
        dateTagtList.append(i.text)
    #print(dateTagtList)

    for j in dateTagtList:
        if j == "Today":
            #print(nowDate)
            dateTextList.append(nowDate)
        else:
            monthstr = j[0:3]
            if monthstr == "Jan":
                month = "1"
            elif monthstr == "Feb":
                month = "2"
            elif monthstr == "Mar":
                month = "3"
            elif monthstr == "Apr":
                month = "4"
            elif monthstr == "May":
                month = "5"
            elif monthstr == "Jun":
                month = "6"
            elif monthstr == "Jul":
                month = "7"
            elif monthstr == "Aug":
                month = "8"
            elif monthstr == "Sep":
                month = "9"
            elif monthstr == "Oct":
                month = "10"
            elif monthstr == "Nov":
                month = "11"
            else :
                month = "12"
                
            daystr = j[4:7].strip()
            day = daystr.strip(",")

            year = j[7:].strip()

            dateTextList.append(year + "-" + month + "-" + day)    
    
    return dateTextList

def titleParser(newsList):
    newsTitleList = []
    
    titleTagList1 = newsList.find_all(class_='fontTitle3 h50')
    for i in titleTagList1:
        newsTitleList.append(i.text)
    titleTagList2 = newsList.find_all(class_='fontTitle3 maxH50')
    for i in titleTagList2:
        newsTitleList.append(i.text)
    
    return newsTitleList

def contentparser(newsList):
    newsContentsList = []
    
    contentsTagList1 = newsList.find_all(class_='fontDesc5 h36')
    for i in contentsTagList1:
        newsContentsList.append(i.text)
    contentsTagList2 = newsList.find_all(class_='fontDesc5 maxH36')
    for i in contentsTagList2:
        newsContentsList.append(i.text)
    return newsContentsList

def parserList(pageString):
    result = []
    bsObj = BeautifulSoup(pageString, "html.parser")
    newsList = bsObj.find("ul",{"class","listDiv l1 mt58 bb1 pb17"})
    #print(newsList)

    dateList = dateParser(newsList)
    #print(len(dateList))

    newsTitleList = titleParser(newsList)
    #print(len(newsTitleList))

    newsContentsList = contentparser(newsList)
    #print(len(newsContentsList))

    for  i in range(0, len(dateList)):
        #result.append({"keyword":"삼성","news_division":"ENG", "news_title" : newsTitleList[i],"news_content":newsContentsList[i],"news_date":dateList[i]})
        result.append({"news_title" : newsTitleList[i],"news_content":newsContentsList[i],"news_date":dateList[i]})
    return result;

def newsDetail(pageString):
    news_image = None
    
    #기자
    try:
        bsObj = BeautifulSoup(pageString, "html.parser")
        byline = bsObj.find("a",{"class","fontReporter2"})
        #print(byline.text)
    except:
        byline = None
    #내용
    try:
        news_contentTag = bsObj.find("div",{"class","content_view"})
        news_contentText = news_contentTag.text
        news_content = news_contentText.strip()
        #print(news_content)
    except:
        news_content = None
        

    #뉴스 이미지
    try:
        filenameTag = bsObj.find("p",{"class","fontTitle6 mb16"})
        filename = filenameCheck(filenameTag.text)
        fileurl = news_contentTag.find("img").get('src')
        #print(fileurl)
    except:
        fileurl = None;

    if fileurl == None:
        print(fileurl)
    else:
        news_image = downImage( fileurl, filename )
        sleep(1)
        
    pyautogui.moveTo(45,91)
    pyautogui.click()
    
    return {"byline": byline.text, "news_content":news_content, "news_image" : news_image}

def newsContextParser():
    newsContextList = []
    pyautogui.scroll(-500)

    for i in range(0,4):
        number = 257 + (210 * i)
        pyautogui.moveTo(300,number)
        pyautogui.click()
        sleep(3)
        pageString = driver.page_source
        sleep(1)
        newsInfo = newsDetail(pageString)
        #print(len(newsInfo))
        #print(newsInfo)
        sleep(1)
        newsContextList.append(newsInfo)
        sleep(1)
        
    pyautogui.moveTo(300,257)
    sleep(1)

    pyautogui.scroll(-705)
    for i in range(0,4):
        number = 257 + (210 * i)
        pyautogui.moveTo(300,number)
        pyautogui.click()
        sleep(3)
        pageString = driver.page_source
        sleep(1)
        newsInfo = newsDetail(pageString)
        #print(newsInfo)
        sleep(1)
        newsContextList.append(newsInfo)
        sleep(1)
        
    pyautogui.moveTo(300,257)
    sleep(1)

    pyautogui.scroll(-705)
    for i in range(0,4):
        number = 257 + (210 * i)
        pyautogui.moveTo(300,number)
        pyautogui.click()
        sleep(3)
        pageString = driver.page_source
        sleep(1)
        newsInfo = newsDetail(pageString)
        #print(newsInfo)
        sleep(1)
        newsContextList.append(newsInfo)
        sleep(1)
        
    pyautogui.moveTo(300,257)
    sleep(1)
    
    pyautogui.scroll(-705)
    for i in range(0,3):
        number = 237 + (210 * i)
        pyautogui.moveTo(300,number)
        pyautogui.click()
        sleep(3)
        pageString = driver.page_source
        sleep(1)
        newsInfo = newsDetail(pageString)
        #print(newsInfo)
        sleep(1)
        newsContextList.append(newsInfo)
        sleep(1)
        
    pyautogui.moveTo(300,257)
    sleep(1)

    return newsContextList

    
#########################MAIN 시작#########################
    
url = "http://www.koreaherald.com/"
driver.get(url) #주소 입력하고 enter

driver.find_element_by_class_name("searchsvg_sch").click()


driver.find_element_by_class_name("inputTxt").send_keys("apple")
driver.find_element_by_xpath('//*[@id="frm_search"]/a').click()
sleep(3)
pageString = driver.page_source

insertNewsList = []

#스크롤 내리기
#pyautogui.scroll(-500)
# 포인터 찍기
#print(pyautogui.position())

#팝업창 지우기
pyautogui.moveTo(681,205)
pyautogui.click()

#NEWS LIST PARSER
newsLists = parserList(pageString)
#print(len(newsLists))

#NEWS CONTEXT PARSER
parserResult = newsContextParser()
#print(len(parserResult))

for i in range(0, len(newsLists)):
    insertNewsList.append({"keyword":searchKey,"news_division" : "ENG", "news_title" : newsLists[i].get("news_title"), "news_content":parserResult[i].get("news_content"), "news_image":parserResult[i].get("news_image"), "news_date" : newsLists[i].get("news_date"),"byline":parserResult[i].get("byline")})

#print(len(insertNewsList))
#print(insertNewsList)

#url = "http://www.koreaherald.com/search/index.php?q=samsung&sort=1&mode=list&np=2"
#driver.get(url) #주소 입력하고 enter
#sleep(3)
#pageString = driver.page_source

#NEWS LIST PARSER
#newsLists = parserList(pageString)

#NEWS CONTEXT PARSER
#parserResult = newsContextParser()

#for i in range(0, len(newsLists)):
#    insertNewsList.append((searchKey, "ENG", newsLists[i].get("news_title"), parserResult[i].get("news_content"), parserResult[i].get("news_image"), newsLists[i].get("news_date"),parserResult[i].get("byline")))
def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
 
 
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow

con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

cur.execute('select cpykeywordseq,cpykeyword from cpykeyword where cpykeyword = :1',cpykeyword)
cur.rowfactory = makeDictFactory(cur)
rows = cur.fetchall()


final = []
for row in rows :
   print(row)
   cpykeywordseq = row['CPYKEYWORDSEQ']
   print(cpykeywordseq)

for row in rows :
   print(row)
   cpykeyword1 = row['CPYKEYWORD']
   print(cpykeyword1)
   
for i in range(0,len(insertNewsList)):
    if insertNewsList[i].get("keyword") == cpykeyword1 :
        final.append({"cpykeywordseq":cpykeywordseq, "news_division":insertNewsList[i].get("news_division"),"news_title":insertNewsList[i].get("news_title"),"news_content":insertNewsList[i].get("news_content"),"news_image":insertNewsList[i].get("news_image"),"news_date":insertNewsList[i].get("news_date"),"byline":insertNewsList[i].get("byline")})
#print(final)
for i in range(0, len(final)):
     testInsert= [(cpykeywordseq,
                   final[i].get("news_division"),
                   final[i].get("news_title"),
                   final[i].get("news_content"),
                   final[i].get("news_image"),
                   final[i].get("news_date"),
                   final[i].get("byline"))]
     cur.executemany("insert into cpynewsinfo(news_no, cpykeywordseq, news_division, news_title, news_content, news_image, news_date, byline) values(news_no.nextval, :1, :2, :3, :4, :5, :6, :7)",testInsert)

print("성공")

con.commit()
cur.close()
