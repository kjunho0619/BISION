from selenium import webdriver
from time import sleep
from bs4 import BeautifulSoup
import cx_Oracle
#from selenium.webdriver import ActionChains
from selenium.webdriver.common.action_chains import ActionChains
import pyautogui
import os
cpykeyword = ["애플"]
searchKeyword = cpykeyword + [" 주가"]

driver = webdriver.Chrome(
    executable_path="C:/pythonWeb/chromedriver.exe"
)

url = "https://www.google.co.kr/webhp?hl=ko&sa=X&ved=0ahUKEwiu0ZGBqIXlAhW-y4sBHdDiB-8QPAgH"
 
driver.get(url) #enter치는것

driver.find_element_by_xpath('//*[@id="tsf"]/div[2]/div[1]/div[1]/div/div[2]/input').send_keys(searchKeyword)
driver.find_element_by_xpath('//*[@id="tsf"]/div[2]/div[1]/div[3]/center/input[1]').click()

stockValue = driver.find_element_by_xpath('//*[@id="knowledge-finance-wholepage__entity-summary"]/div/g-card-section/div/g-card-section/span[1]/span/span[1]').text
stockValue = stockValue.replace(",","")
country = driver.find_element_by_xpath('//*[@id="knowledge-finance-wholepage__entity-summary"]/div/g-card-section/div/g-card-section/span[1]/span/span[2]').text
moveValue = driver.find_element_by_xpath('//*[@id="knowledge-finance-wholepage__entity-summary"]/div/g-card-section/div/g-card-section/span[2]/span[1]').text
sign = moveValue[:1]
moveValue = moveValue[1:]

per = driver.find_element_by_xpath('//*[@id="knowledge-finance-wholepage__entity-summary"]/div/g-card-section/div/g-card-section/span[2]/span[2]/span[1]').text
per = per.replace("(","")
per = per.replace(")","")
per = per[: - 1]
total = []
print(sign)
print(moveValue)
total.append({"stockValue":stockValue,"country":country,"moveValue":moveValue,"per":per,"sign":sign})
print(total)
os.putenv('NLS_LANG','KOREAN_KOREA.UTF8');
def makeDictFactory(cursor):
   columnNames = [d[0] for d in cursor.description]
 
 
   def createRow(*args):
      return dict(zip(columnNames, args))
 
 
   return createRow

con = cx_Oracle.connect("bision/project@localhost:1521/XE")
cur = con.cursor()

cur.execute('select cpykeywordseq from cpykeyword where cpykeyword = :1',cpykeyword)
cur.rowfactory = makeDictFactory(cur)
rows = cur.fetchall()

print(rows)

for row in rows :
   print(row)
   cpykeywordseq = row['CPYKEYWORDSEQ']
   print(cpykeywordseq)

for i in range(0, len(total)):
     cpyrlikeyword1 = [(cpykeywordseq,
                       total[i].get("stockValue"),
                       total[i].get("country"),
                       total[i].get("moveValue"),
                       total[i].get("per"),
                       total[i].get("sign"))]
     cur.executemany("insert into cpystock values(:1, :2, :3, :4, :5, :6)",cpyrlikeyword1)
     print("성공")
print("성공")
con.commit()
cur.close()
#driver.close()
